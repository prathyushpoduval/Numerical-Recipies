package com.nr.sort;

public interface EquivalenceInf {
  public boolean equiv(final int jj, final int kk);
}
