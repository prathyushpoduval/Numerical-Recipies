package com.nr;

public interface RealMultiValueFun {
	
	public double[] funk(double[] x);

}
