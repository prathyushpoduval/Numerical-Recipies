package com.nr;

public interface UniVarRealMultiValueFun {
	
	public double[] funk(double x);

}
